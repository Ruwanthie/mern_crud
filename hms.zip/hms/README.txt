


To run application, Open command prompt
* Go to client folder and then type command "npm start" to run the frontend
* Go to server folder and then type command "node index" to run the backend

Unit test to check api/service which will be retrive all the details of doctors 
can be find in test folder/test.js