var should = require('should');
var app = require('./client');
var request = require('supertest');

describe('GET /read', function() {

  it('should respond with JSON array', function(done) {
    request(app)
      .get('/read')
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function(err, res) {
        if (err) return done(err);
        res.body.should.be.instanceof(Array);
        done();
      });
  });
});