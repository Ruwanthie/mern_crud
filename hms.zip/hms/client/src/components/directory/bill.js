import React, { Component } from 'react';
import './bill.css';

class Bill extends Component {

  constructor(props){
    super(props);
    this.state = {
      title: "Payment Information",
      act: 0,
      index: '',
      datas: []
    }
  }

  componentDidMount(){
    this.refs.wardname.focus();
  }

 

  fSubmit = (e) => {
    e.preventDefault();
    console.log('try');

    let datas = this.state.datas;
    let wardname = this.refs.wardname.value;
    let days = this.refs.days.value;
    let price = this.refs.price.value;
    let charge = this.refs.charge.value;
    let sum = charge*days;
    let x = parseInt(price, 10);
    let y = parseInt(sum, 10);
    console.log(x);
    let total_amount = x + y ;
    console.log(total_amount);
  
    let data = {
      wardname, days, price, charge, total_amount
    }
    datas.push(data);
 
    
    this.setState({
      datas: datas,
      act: 0
    });

    this.refs.myForm.reset();
    this.refs.wardname.focus();
  }

  fRemove = (i) => {
    let datas = this.state.datas;
    datas.splice(i,1);

    this.setState({
      datas: datas
    });

    this.refs.myForm.reset();
    this.refs.wardname.focus();
  }

  render() {
   
    let datas = this.state.datas;
    return (
      <div className="Bill">
        <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {this.state.title}
        </h3>
        <form ref="myForm" className="myForm">
          <input type="text" ref="wardname" placeholder="Ward Name" className="formField"/>
          <input type="number" ref="price" placeholder="X-Ray Price (Rs.)" className="formField"/>
          <input type="number" ref="charge" placeholder="Ward Charge Per Day (Rs.)" className="formField"/>
          <input type="number" ref="days" placeholder="Number of days" className="formField"/>
          <button onClick={(e)=>this.fSubmit(e)} className="myButton">Calculate</button>
        </form>
        <pre>
          
          <b>
          {datas.map((data, i) => 
          
            <li key={i} className="myList">
               Receipt No : {i+1} <br></br>
               Wardname : {data.wardname} <br></br>
               X-Ray Price (Rs.): {data.price} <br></br>
               Ward Charge (Rs.): {data.charge*data.days} <br></br>
               Total Bill Amount (Rs.) : {data.total_amount}
               &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 
               &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
               &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
              <button onClick={()=>this.fRemove(i)} className="myListButton">remove</button>
              <label>----------------------------------------------------------------------------</label>
            </li>
            )}
        </b>
       
        </pre>
      </div>
    );
  }
}

export default Bill;
