import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { deleteDirectoryEntry, directoryList } from '../../actions/index';
import { Link } from "react-router-dom";


class List extends Component {
   constructor(props){
     super(props);
     this.state = { list: [] };
     this.confirmDelete = this.confirmDelete.bind(this);
   }
   async getAList() {
     let results = await this.props.directoryList();
     this.setState({ list : results.payload.data });
   }
   componentDidMount(){
     this.getAList();
   }
   async confirmDelete(e){
     if ( window.confirm('Are you sure you wish to delete this item?') ) {
          let results = await this.props.deleteDirectoryEntry(e.target.id);
          if( results.payload.data.response === 'success' ) {
              this.getAList();
          }
     }
   }



   displayAList(){
     if( Object.keys(this.state.list).length > 0 ) {
         const row = this.state.list.map( ( item, i ) => {
            let rowNumber = i + 1;
            return <tr key={i}><th scope="row">{rowNumber}</th><td>{item.doctorID}</td><td>{item.firstName}</td><td>{item.lastName}</td><td>{item.leadingWard}</td><td>{item.registeredYear}</td><td><Link className="btn btn-warning" to={"/edit/"+item._id}>Edit</Link>&nbsp;<Link id={item._id} onClick={this.confirmDelete} className="btn btn-danger" to="/">Delete</Link></td></tr>
         });
         return (
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Doctor ID</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Leading Ward</th>
                  <th scope="col">Registered Year</th>
                  <th scope="col">Edit / Delete</th>
                </tr>
              </thead>
              <tbody>
                { row }
              </tbody>
            </table>
         );
     } else {
         return <p><em>There are no doctors registered at the moment.</em></p>;
     }
   }
   render(){
      return(
        <div className="col-lg-12 col-md-12">
          <h2>List of Doctors</h2>
          <fieldset className="form-group">
          <input type="text" className="form-control" placeholder="Search"/>
          </fieldset>
          { this.displayAList() }
        </div> 
      );
   }
}

const mapStateToDispatch = (dispatch) => {
  return bindActionCreators({ directoryList, deleteDirectoryEntry }, dispatch);
};

export default connect(null, mapStateToDispatch)(List);