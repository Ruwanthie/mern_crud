import React, { Component } from 'react';
import { Redirect } from 'react-router-dom'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Formik, Field, Form } from 'formik';
import Yup from 'yup';
import { updateDirectoryEntry, newDirectoryEntry } from '../../actions/index';

const validationSchema = Yup.object().shape({
    doctorID: Yup.string().required('Doctor ID is required!'),
    firstName: Yup.string().required('First Name is required!'),
    lastName: Yup.string().required('Last Name is required!'),
    leadingWard: Yup.string().required('Leading Ward is required!'),
    registeredYear: Yup.string().required('Registered Year is required!'),
    
});

class form extends Component {
   constructor(props){
      super(props);
      this.state = { id: typeof this.props.row._id !== 'undefined' ? this.props.row._id : '', doctorID: typeof this.props.row.doctorID !== 'undefined' ? this.props.row.doctorID : '', firstName: typeof this.props.row.firstName !== 'undefined' ? this.props.row.firstName : '', lastName: typeof this.props.row.lastName !== 'undefined' ? this.props.row.lastName : '', leadingWard: typeof this.props.row.leadingWard !== 'undefined' ? this.props.row.leadingWard : '',registeredYear: typeof this.props.row.registeredYear !== 'undefined' ? this.props.row.registeredYear : '', redirect: false }
   }
   async createUpdateRecord(values){
      let results;
      if( this.props.mode === 'edit' ) {
        results = await this.props.updateDirectoryEntry(values);
        if( results.payload.data.response === 'success' ) {
            this.setState({ redirect: true });
        } else {
            console.log(results.payload.data.response);
        }
      } else {
        results = await this.props.newDirectoryEntry(values);
        if( results.payload.data.response === 'success' ) {
            this.setState({ redirect: true });
        } else {
            console.log(results.payload.data.response);
        }
      }
   }
   render(){
      if( this.state.redirect ) {
          return (
            <Redirect to="/" />
          );
      }
      return(
         <div>
           <Formik
             initialValues={{
               doctorID: this.state.doctorID,
               firstName: this.state.firstName,
               lastName: this.state.lastName,
               leadingWard: this.state.leadingWard,
               registeredYear: this.state.registeredYear,
               id: this.state.id
             }}
             validationSchema={validationSchema}
             onSubmit={ values => {
                this.createUpdateRecord(values);
             }}
             render={({ errors, touched }) => (
               <Form>
                 <div className="row">
                   <div className="col-lg-12 col-md-12">
                   <h2>{ this.props.mode === 'edit' ? 'Edit Entry' : 'New Entry' }</h2>
                   </div>
                 </div> 
                 <div className="row">
                   <div className={`form-group col-md-6 ${errors.doctorID && touched.doctorID && 'has-error'}`}>
                     <label htmlFor="doctorID">Doctor ID</label>
                     <Field name="doctorID" className="form-control" placeholder="Doctor ID" type="text" />
                      { errors.doctorID && touched.doctorID && <span className="help-block">{errors.doctorID}</span> }
                   </div>
                 </div>
                 <div className="row">
                   <div className={`form-group col-md-6 ${errors.firstName && touched.firstName && 'has-error'}`}>
                     <label htmlFor="firstName">First Name</label>
                     <Field name="firstName" className="form-control" placeholder="First Name" type="text" />
                      { errors.firstName && touched.firstName && <span className="help-block">{errors.firstName}</span> }
                   </div>
                   <div className={`form-group col-md-6 ${errors.lastName && touched.lastName && 'has-error'}`}>
                     <label htmlFor="lastName">Last Name</label>
                     <Field name="lastName" className="form-control" placeholder="Last Name" type="text" />
                      { errors.lastName && touched.lastName && <span className="help-block">{errors.lastName}</span> }
                   </div>
                 </div>
                 <div className="row">
                   <div className={`form-group col-md-6 ${errors.leadingWard && touched.leadingWard && 'has-error'}`}>
                     <label htmlFor="leadingWard">Leading Ward</label>
                     <Field name="leadingWard" className="form-control" placeholder="Leading Ward" type="text" />
                     {/* <select name="leadingWard" className="form-control">
                      <option>--Please select the ward--</option>
                      <option>Accident ward</option>
                     </select> */}
                      { errors.leadingWard && touched.leadingWard && <span className="help-block">{errors.leadingWard}</span> }
                   </div>
                   <div className={`form-group col-md-6 ${errors.registeredYear && touched.registeredYear && 'has-error'}`}>
                     <label htmlFor="registeredYear">Registered Year</label>
                     <Field name="registeredYear" className="form-control" placeholder="Registered Year" type="number" />
                      { errors.registeredYear && touched.registeredYear && <span className="help-block">{errors.registeredYear}</span> }
                   </div>
                 </div>
                 <div className="row">
                   <div className="col-lg-12 col-md-12">
                      <button type="submit" className="btn btn-primary">Submit</button>
                   </div>
                 </div>
               </Form>
             )} />
         </div>
      );
   }
}

const mapStateToDispatch = (dispatch) => {
  return bindActionCreators({ updateDirectoryEntry, newDirectoryEntry }, dispatch);
};

export default connect(null, mapStateToDispatch)(form);