const express = require('express');
const router = express.Router();
const Directory = require('../models/directory');

module.exports = function() {

  /* Get doctors details */
  router.get('/read', async (req, res) => {
    try {
      let directory_list = await Directory.find({});
      res.send(directory_list);
    } catch ( err ) {
      return res.status(500).send(err);
    }
  });

  /* Create a doctor profile*/
  router.post("/create", async ( req, res ) => {
      let directory = new Directory({
         doctorID: req.body.doctorID,
         firstName: req.body.firstName,
         lastName: req.body.lastName,
         leadingWard: req.body.leadingWard,
         registeredYear: req.body.registeredYear
      });
      try{
        let newDirectory = await directory.save();
        res.send({ response: 'success'});
      } catch (err){
        res.send({ response: err });
      }
  });

  /* Get a listing by a doctor id */
  router.get('/readbyid/', async ( req, res ) => {
     try {
       let record = await Directory.findOne({ _id: req.query.id });
       res.send(record);
     } catch ( err ) {
       return res.status(500).send(err);
     }
  });
     
  /* Update a doctor profile */
  router.put('/update', async ( req, res ) => {
      try {
        let directory = await Directory.findOneAndUpdate({ _id: req.body.id }, req.body, { new: true });
        res.send({ response: 'success' });
      } catch (err) {
        res.send({ response: err });
      }
  });

  /* Delete a doctor profile */
  router.delete('/delete', async (req, res) => {
      try {
        let directory = await Directory.findOneAndRemove({ _id: req.query.entryid });
        return res.send({ response: 'success' });
      } catch (err) {
        return res.send({ response: err });
      }
  });

  return router;

};