'use strict';

const mongoose = require('mongoose'), Schema = mongoose.Schema;

const DirectorySchema = new Schema({
  doctorID: { type: String, required: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  leadingWard: { type: String, required: true },
  registeredYear: { type: String, required: true }
});

// Compile model from schema

module.exports = mongoose.model('Directory', DirectorySchema);